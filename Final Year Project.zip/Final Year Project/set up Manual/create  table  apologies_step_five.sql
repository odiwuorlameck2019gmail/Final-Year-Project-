USE Employees_Records;

CREATE TABLE apologies(
work_id   varchar(80),
apologatic_date  datetime DEFAULT CURRENT_TIMESTAMP
);