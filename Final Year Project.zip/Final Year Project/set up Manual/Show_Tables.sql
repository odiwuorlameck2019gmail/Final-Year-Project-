USE Employees_Records;
show tables;
