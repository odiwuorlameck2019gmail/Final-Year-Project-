USE employees_records;
CREATE table   arrival_time(
arrival_date datetime  DEFAULT CURRENT_TIMESTAMP ,
work_id  varchar(50)
);