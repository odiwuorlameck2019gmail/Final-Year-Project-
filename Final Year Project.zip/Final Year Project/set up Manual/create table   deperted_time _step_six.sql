USE Employees_Records;

CREATE TABLE deperted_time(
work_id  varchar(80),
departed_date  datetime DEFAULT CURRENT_TIMESTAMP
  );