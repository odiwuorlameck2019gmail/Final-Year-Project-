
CREATE DATABASE  employees_records;

